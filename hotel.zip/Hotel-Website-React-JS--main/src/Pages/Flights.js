import React from "react";
import TextData from "../Components/TextData";

const Flights = () => {
    return (
        <>
            <TextData information='This is Flights page' />
        </>
    );
};

export default Flights;
